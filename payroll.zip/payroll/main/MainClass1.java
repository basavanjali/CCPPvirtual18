package com.cg.payroll.main;

import com.cg.payroll.sevices.PayrollServicesImpl;

public class MainClass1 {
	public static void main(String [] str){
		PayrollServicesImpl payrollservices= new PayrollServicesImpl();
	int i=payrollservices.acceptAssociateDetails("Anjali", "Ulligadla", "anjali123@gmail.com", "java", "Analyst", "10000", 243000, 652000, 1000, 1000,5666663, "CITI", "CITI000123");
	System.out.println(payrollservices.getAssociatDetails(i).getFirstName());
	System.out.println(payrollservices.calculateNetSalary(i));
	System.out.println(payrollservices.getAssociatDetails(i).getSalary().getMonthlyTax());
	}
}