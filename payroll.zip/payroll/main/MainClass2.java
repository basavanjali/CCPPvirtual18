package com.cg.payroll.main;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;

public class MainClass2 {

	public static void main(String[] args) {
			Associate associate = new Associate(1234, 450000, "Anjali", "Ulligad", "training", "analyst", "ASDF123", "Anjali@gmail.com", new Salary(35000, 123, 342, 123, 100, 1560, 1256, 167, 780, 38000, 32000), new BankDetails(54326, "CITI", "CITI0005"));
		System.out.println(associate.getSalary().getBasicSalary());

	}

}
