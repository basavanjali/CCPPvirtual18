package com.cg.payroll.sevices;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;

public class PayrollServicesImpl {
	private PayrollDAOServicesImpl daoServices;
	public PayrollServicesImpl(){
		daoServices=new PayrollDAOServicesImpl();
	}
	public int acceptAssociateDetails(String firstName,String lastName,String emailId,String department,String designation,String pancard,
			int yearlyInvestmentUnder80C,float basicSalary,float epf, float companyPf,int accountNumber,String bankName,String ifscCode){
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));

	}
public float calculateNetSalary(int associateID){
		Associate associate = this.getAssociatDetails(associateID);
		if(associate!=null){
			float basicSalary=associate.getSalary().getBasicSalary(),yi80C=associate.getYearlyInvestmentUnder80C(), personalAllowances, conveyanceAllowance,otherAllowances,hra,gratuity,annualSalary,grossSalary,companyPf=associate.getSalary().getCompanyPf(),epf=associate.getSalary().getEpf();
			float b,tax,nonTax;
			personalAllowances=(float) 0.3*basicSalary;
			conveyanceAllowance=(float)0.2*basicSalary;
			otherAllowances=(float)0.1*basicSalary;
			hra=(float)0.25*basicSalary;
			gratuity=(float)0.05*basicSalary;
			grossSalary=basicSalary+personalAllowances+conveyanceAllowance+otherAllowances+hra+companyPf;
			nonTax=yi80C+12*(companyPf+epf);
			associate.getSalary().setConveyenceAllowance(conveyanceAllowance);
			associate.getSalary().setGratuity(gratuity);
			associate.getSalary().setHra(hra);
			associate.getSalary().setOtherAllowance(otherAllowances);
			if(nonTax>150000)
				nonTax=150000;
			annualSalary=grossSalary*12;
			associate.getSalary().setGrossSalary(grossSalary);
			if(annualSalary<250000){
				associate.getSalary().setMonthlyTax(0);
				associate.getSalary().setNetSalary((annualSalary/12)-epf-companyPf);
				return ((annualSalary/12)-epf-companyPf); 
			}
			else if (annualSalary>250000 && annualSalary<=500000){
				tax=(float)0.1*(annualSalary-250000-nonTax);
				associate.getSalary().setMonthlyTax(tax/12);
				associate.getSalary().setNetSalary((annualSalary/12)-(tax/12)-epf-companyPf);
				return ((annualSalary/12)-(tax/12)-epf-companyPf);
			}
			else if(annualSalary>500000 && annualSalary<=1000000){
				b=(float)0.1*(250000-nonTax);
				tax=(annualSalary-500000)*(float)0.2+b;
				associate.getSalary().setMonthlyTax(tax/12);
				associate.getSalary().setNetSalary((annualSalary/12)-(tax/12)-epf-companyPf);
				return ((annualSalary/12)-(tax/12)-epf-companyPf);
			}
			else if(annualSalary>1000000){
				int i=2;
			System.out.println(i);
				b=(float)0.1*(250000-nonTax);
				tax=(float)0.3*(annualSalary-1000000)+b+100000;
				associate.getSalary().setMonthlyTax(tax/12);
				associate.getSalary().setNetSalary((annualSalary-tax)/12-epf-companyPf);
				return ((annualSalary-tax)/12-epf-companyPf);
			}
		}
		return 0;
	}
	public Associate getAssociatDetails(int associateID){
		return daoServices.getAssociate(associateID);
	}
	public Associate[] getAllAssociateDetails(){

		return null;

	}

}