package com.cg.leavemanagement.beans;

public class LeaveApplication {
	private int noOfDays,from,to;
	private String leaveType,reason,applicationStatus;
	public LeaveApplication(int noOfDays, int from, int to, String leaveType, String reason, String applicationStatus) {
		super();
		this.noOfDays = noOfDays;
		this.from = from;
		this.to = to;
		this.leaveType = leaveType;
		this.reason = reason;
		this.applicationStatus = applicationStatus;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public int getFrom() {
		return from;
	}
	public void setFrom(int from) {
		this.from = from;
	}
	public int getTo() {
		return to;
	}
	public void setTo(int to) {
		this.to = to;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getApplicationStatus() {
		return applicationStatus;
	}
	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}
	@Override
	public String toString() {
		return "LeaveApplication [noOfDays=" + noOfDays + ", from=" + from + ", to=" + to + ", leaveType=" + leaveType
				+ ", reason=" + reason + ", applicationStatus=" + applicationStatus + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((applicationStatus == null) ? 0 : applicationStatus.hashCode());
		result = prime * result + from;
		result = prime * result + ((leaveType == null) ? 0 : leaveType.hashCode());
		result = prime * result + noOfDays;
		result = prime * result + ((reason == null) ? 0 : reason.hashCode());
		result = prime * result + to;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LeaveApplication other = (LeaveApplication) obj;
		if (applicationStatus == null) {
			if (other.applicationStatus != null)
				return false;
		} else if (!applicationStatus.equals(other.applicationStatus))
			return false;
		if (from != other.from)
			return false;
		if (leaveType == null) {
			if (other.leaveType != null)
				return false;
		} else if (!leaveType.equals(other.leaveType))
			return false;
		if (noOfDays != other.noOfDays)
			return false;
		if (reason == null) {
			if (other.reason != null)
				return false;
		} else if (!reason.equals(other.reason))
			return false;
		if (to != other.to)
			return false;
		return true;
	}
}