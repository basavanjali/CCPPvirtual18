package com.cg.leavemanagement.beans;

public class Leave {
	
	private int holidayLeaves,usedLeaves,totalLeaves;
	public Leave(int holidayLeaves, int usedLeaves, int totalLeaves) {
		super();
		this.holidayLeaves = holidayLeaves;
		this.usedLeaves = usedLeaves;
		this.totalLeaves = totalLeaves;
	}

	public int getHolidayLeaves() {
		return holidayLeaves;
	}

	public void setHolidayLeaves(int holidayLeaves) {
		this.holidayLeaves = holidayLeaves;
	}

	public int getUsedLeaves() {
		return usedLeaves;
	}

	public void setUsedLeaves(int usedLeaves) {
		this.usedLeaves = usedLeaves;
	}

	public int getTotalLeaves() {
		return totalLeaves;
	}

	public void setTotalLeaves(int totalLeaves) {
		this.totalLeaves = totalLeaves;
	}

	@Override
	public String toString() {
		return "Leave [holidayLeaves=" + holidayLeaves + ", usedLeaves=" + usedLeaves + ", totalLeaves=" + totalLeaves
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + holidayLeaves;
		result = prime * result + totalLeaves;
		result = prime * result + usedLeaves;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Leave other = (Leave) obj;
		if (holidayLeaves != other.holidayLeaves)
			return false;
		if (totalLeaves != other.totalLeaves)
			return false;
		if (usedLeaves != other.usedLeaves)
			return false;
		return true;
	}
	
	
}
