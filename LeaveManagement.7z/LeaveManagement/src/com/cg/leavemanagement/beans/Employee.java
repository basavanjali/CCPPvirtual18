package com.cg.leavemanagement.beans;
import java.util.Arrays;
public class Employee {
	private int employeeId,mobileNo;
	private String firstName,lastName,emailId;
	private Leave[] leaves;
	public Employee(int employeeId, int mobileNo, String firstName, String lastName, String emailId, Leave[] leaves) {
		super();
		this.employeeId = employeeId;
		this.mobileNo = mobileNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.leaves = leaves;
	}
	public Employee(int mobileNo, String firstName, String lastName, String emailId, Leave[] leaves) {
		super();
		this.mobileNo = mobileNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.leaves = leaves;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Leave[] getLeaves() {
		return leaves;
	}
	public void setLeaves(Leave[] leaves) {
		this.leaves = leaves;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", mobileNo=" + mobileNo + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", emailId=" + emailId + ", leaves=" + Arrays.toString(leaves) + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
		result = prime * result + employeeId;
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + Arrays.hashCode(leaves);
		result = prime * result + mobileNo;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (emailId == null) {
			if (other.emailId != null)
				return false;
		} else if (!emailId.equals(other.emailId))
			return false;
		if (employeeId != other.employeeId)
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (!Arrays.equals(leaves, other.leaves))
			return false;
		if (mobileNo != other.mobileNo)
			return false;
		return true;
	}
}
