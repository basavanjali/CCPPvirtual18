package com.cg.banking.test;
import static org.junit.Assert.assertEquals;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.banking.beans.*;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.utility.BankingUtility;
public class BankingServicesTest {
	private static BankingServices services;
	@BeforeClass
	public static void setUpTestEnv(){
		services=new BankingServicesImpl();	
	}
	@Before
	public  void setUpMockData() {
		Customer cust1=new Customer("Avani","Reddy","av@gmail","enn24",new Address("hyd","tg",5009),new Address("hyderabad","telangana",6009));
		Customer cust2=new Customer("Shishir","Reddy","sh@gmail","enn23",new Address("hyd","tg",5003),new Address("hyderabad","telangana",6005));
		cust1.setCustomerId(BankingUtility.Customer_Id_Gen++);
		cust2.setCustomerId(BankingUtility.Customer_Id_Gen++);
		BankingDAOServicesImpl.customers.put(cust1.getCustomerId(), cust1);
		BankingDAOServicesImpl.customers.put(cust2.getCustomerId(), cust2);
		Account acc1=new Account("savings",50000);
		Account acc2=new Account("current",60000);
		acc1.setAccountNo(BankingUtility.AccountNo_Id_Gen++);
		acc2.setAccountNo(BankingUtility.AccountNo_Id_Gen++);
		acc1.setStatus("active");
		acc2.setStatus("active");
		BankingDAOServicesImpl.customers.get(cust1.getCustomerId()).getAccount().put(acc1.getAccountNo(), acc1);
		BankingDAOServicesImpl.customers.get(cust2.getCustomerId()).getAccount().put(acc2
				.getAccountNo(), acc2);
		BankingDAOServicesImpl.customers.get(cust1.getCustomerId()).getAccount().get(acc1.getAccountNo()).setPinNumber(2899);
		BankingDAOServicesImpl.customers.get(cust2.getCustomerId()).getAccount().get(acc2.getAccountNo()).setPinNumber(2900);
	}
	@Test
	public void validCustomerDetails() throws CustomerNotFoundException,BankingServicesDownException{
		int actual=services.acceptCustomerDetails("fg", "gg", "S", "ASDF", "ASD", "ASFD", 254, "ASF", "RYU", 54);
		assertEquals(113,actual);
	}
	@Test
	public void testOpenAccountForValidDetails() throws CustomerNotFoundException,BankingServicesDownException,AccountNotFoundException,InvalidAccountTypeException,InvalidAmountException{
		long actual=services.openAccount(111, "current", 50000);
		Assert.assertEquals(22, actual);
	}
	@Test
	public void testOpenAccountForValidCustomerId() throws InvalidAccountTypeException, InvalidAmountException, CustomerNotFoundException, BankingServicesDownException{
		long actual=services.openAccount(111,"savings",50000);
		Assert.assertEquals(22, actual);	
	}
	@Test(expected=CustomerNotFoundException.class)
	public void  testOpenAccountForInvalidCustomerId()  throws InvalidAccountTypeException,InvalidAmountException,CustomerNotFoundException,BankingServicesDownException{
		long actual=services.openAccount(115,"savings",59000);
		assertEquals(22,actual);
	}
	@Test
	public void testOpenAccountForValidAccountType() throws InvalidAccountTypeException,InvalidAmountException,CustomerNotFoundException,BankingServicesDownException{
		services.openAccount(111,"savings",59000);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testDepositAmountForInvalidCustomerId() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException{
		services.depositAmount(105,24,8000);
	}
	@Test(expected=InvalidAccountTypeException.class)
	public void testOpenAccountForInvalidAccountType() throws InvalidAccountTypeException,InvalidAmountException,CustomerNotFoundException,BankingServicesDownException{
		services.openAccount(111,"Existing",59000);
	}
	@Test
	public void testOpenAccountForValidAmount() throws InvalidAmountException,BankingServicesDownException,InvalidAccountTypeException, CustomerNotFoundException{
		services.openAccount(112, "Savings",5000);
	}
	@Test(expected=InvalidAmountException.class)
	public void testOpenAccountForInvalidAmount() throws InvalidAmountException,BankingServicesDownException,InvalidAccountTypeException, CustomerNotFoundException{
		services.openAccount(112, "Savings",-30);
	}
	@Test
	public void testDepositAmountForValidAccountNo() throws AccountNotFoundException, CustomerNotFoundException, BankingServicesDownException, AccountBlockedException{
		services.depositAmount(112, 21, 60000);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testDepositAmountForInvalidAccountNo() throws AccountNotFoundException, CustomerNotFoundException, BankingServicesDownException, AccountBlockedException{
		services.depositAmount(112, 29, 5000);
	}
	@Test(expected=AccountBlockedException.class)
	public void testDepositAmountForInValidPinNo() throws AccountBlockedException, CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		BankingDAOServicesImpl.customers.get(111).getAccount().get(20l).setStatus("blocked");
		services.depositAmount(111,20,50000);
	}
	@Test
	public void testWithdrawAmountForValidAmount() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
	float actual=services.withdrawAmount(111, 20, 5000, 2899);
	Assert.assertEquals(45000, actual, 0);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testForWithdrawAmountForInvalidCustomerId() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		services.withdrawAmount(222, 25, 6000, 9999);
	}
	@Test(expected=InsufficientAmountException.class)
	public void testWithdrawAmountForInvalidAmount() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
	float actual=services.withdrawAmount(111, 20, 500000, 2899);
		Assert.assertEquals(25000, actual,0);
	}
	@Test
	public void testWithdrawAmountForValidPin() throws InvalidPinNumberException, InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException{
		float actual=services.withdrawAmount(111, 20, 10000, 2899);	
		Assert.assertEquals(40000, actual, 0);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testWithdrawAmountForInvalidPin() throws InvalidPinNumberException, InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException{
		services.withdrawAmount(111, 20, 50000, 3000);	
	}
	
	@After
	public  void tearDownMockData(){
		BankingDAOServicesImpl.customers.clear();
		BankingUtility.Customer_Id_Gen=111;
		BankingUtility.AccountNo_Id_Gen=20;
	}
	@AfterClass
	public static void tearDownTestEnv(){
		services=null;
	}
}
