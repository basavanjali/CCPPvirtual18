package com.cg.banking.daoservices;

import com.cg.banking.beans.Account;


import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.BankingUtility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
@Component(value="daoServices")

public class BankingDAOServicesImpl implements BankingDAOServices {
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public int insertCustomer(Customer customer) {
		
		return 0;
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		
		return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		
		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		
		return null;
	}

	@Override
	public List<Customer> getCustomers() {
		
		return null;
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		
		return null;
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		
		return null;
	}
}
/*public static HashMap<Integer,Customer>customers=new HashMap<>();
Random rand=new Random();

@Override
public int insertCustomer(Customer customer) {
	customer.setCustomerId(BankingUtility.Customer_Id_Gen++);
	customers.put(customer.getCustomerId(),customer);
	return customer.getCustomerId();

}

@Override
public long insertAccount(int customerId, Account account) {
	account.setAccountNo(BankingUtility.AccountNo_Id_Gen++);
	getCustomer(customerId).getAccount().put(account.getAccountNo(), account);
	return account.getAccountNo();
}

@Override
public boolean updateAccount(int customerId, Account account) {
	getCustomer(customerId).getAccount().put(account.getAccountNo(),account);

	return false;
}

@Override
public int generatePin(int customerId, Account account) {
	getAccount(customerId,account.getAccountNo()).setPinNumber(rand.nextInt(444)+100);
	return account.getPinNumber();
}


	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		transaction.setTransactionId(BankingUtility.Transaction_Id_Gen);
		if(getAccount(customerId,accountNo).getTransaction().put(BankingUtility.Transaction_Id_Gen++,transaction)!=null)
		return true;
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		customers.remove(customerId);
		return true;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		getCustomer(customerId).getAccount().remove(accountNo);


		return true;
	}

	@Override
	public Customer getCustomer(int customerId) {
		return customers.get(customerId);
		 
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		return customers.get(customerId).getAccount().get(accountNo);
	}

	@Override
	public List<Customer> getCustomers() {
		return new ArrayList<Customer>(customers.values());
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		return new ArrayList<Account>(getCustomer(customerId).getAccount().values());
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return new ArrayList<>(getAccount(customerId, accountNo).getTransaction().values());
	}*/


