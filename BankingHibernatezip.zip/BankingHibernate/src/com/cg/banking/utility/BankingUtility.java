package com.cg.banking.utility;

public class BankingUtility {
	public static int Customer_Id_Gen=111;
	public static long AccountNo_Id_Gen=20;
	public static int Transaction_Id_Gen=2020;
	public static final String ACCOUNT_STATUS_ACTIVE="active";
	public static final String ACCOUNT_STATUS_INACTIVE="inactive";
}
